// Vercel serverless function: scans a bank statement and returns customer credits as JSON.
// Env vars: ANTHROPIC_API_KEY (required), PAID_ACCESS_CODE (placeholder gate until real auth/billing), ANTHROPIC_MODEL (optional)
const MAX_BYTES = 3 * 1024 * 1024;
const PROMPT = `You are reading a company bank statement. Extract ONLY incoming credits (money received), not debits or fees.
Return ONLY valid JSON, no prose, in this exact shape:
{"currency":"NGN","credits":[{"date":"YYYY-MM-DD","payer":"name or narration of sender","amount":1234.56,"reference":"transaction reference or empty string"}]}
Use plain numbers for amount (no commas or symbols). If a date is unclear use an empty string. If nothing is found return {"currency":"NGN","credits":[]}.`;

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST." });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ error: "Server is missing ANTHROPIC_API_KEY." });
  if (!process.env.PAID_ACCESS_CODE || req.headers["x-access-code"] !== process.env.PAID_ACCESS_CODE)
    return res.status(402).json({ error: "Statement scanning is available on paid plans. Check your access code." });

  const { mediaType, data, text } = req.body || {};
  let block;
  if (mediaType === "application/pdf" && data) block = { type: "document", source: { type: "base64", media_type: mediaType, data } };
  else if (/^image\/(png|jpeg|webp|gif)$/.test(mediaType || "") && data) block = { type: "image", source: { type: "base64", media_type: mediaType, data } };
  else if (typeof text === "string" && text.trim()) block = { type: "text", text: "Statement (CSV/text):\n" + text };
  else return res.status(400).json({ error: "Upload a PDF, image, or CSV statement." });
  if ((data || text || "").length * 0.75 > MAX_BYTES) return res.status(413).json({ error: "File is too large (3 MB max)." });

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
        max_tokens: 4000,
        messages: [{ role: "user", content: [block, { type: "text", text: PROMPT }] }]
      })
    });
    const j = await r.json();
    if (!r.ok) return res.status(502).json({ error: (j.error && j.error.message) || "AI request failed." });
    const raw = (j.content || []).map(c => c.text || "").join("").replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(raw);
    const credits = (parsed.credits || [])
      .map(c => ({ date: String(c.date || ""), payer: String(c.payer || ""), amount: Number(c.amount), reference: String(c.reference || "") }))
      .filter(c => isFinite(c.amount) && c.amount > 0);
    return res.status(200).json({ currency: parsed.currency || "NGN", credits });
  } catch (e) {
    return res.status(500).json({ error: "Could not read this statement. Try a clearer PDF or a CSV export." });
  }
};
